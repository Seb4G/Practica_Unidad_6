#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
using namespace sf;

int main() {
    RenderWindow App(VideoMode(800, 600), "Space");
    Event evt;
    CircleShape circle(30);
    circle.setFillColor(Color::Green);
    Vector2f position(0.0f, 300.0f);
    float velocidad = (0.0f);
    float aceleracion = (0.5f);
    float freno = (0.9f);

    while (App.isOpen()) {
        while (App.pollEvent(evt)) {
            if (evt.type == Event::Closed)
                App.close();
            if (Keyboard::isKeyPressed(Keyboard::Left)) {
                velocidad -= aceleracion;
            }
            else if (Keyboard::isKeyPressed(Keyboard::Right)) {
                velocidad += aceleracion;
            }
            else {
                velocidad *= freno;
            }
            position.x += velocidad;
            if (position.x > 800) {
                position.x = 0;
            }
            else if (position.x < 0) {
                position.x = 800;
            }
            App.clear();
            circle.setPosition(position);
            App.draw(circle);
            App.display();
        }
    }
    return 0;
}
