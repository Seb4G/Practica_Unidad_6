#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
using namespace sf;

int main() {
    RenderWindow App(VideoMode(800, 600), "Fast & Furious");
    Event evt;
    CircleShape circle(30);
    circle.setFillColor(Color::Green);
    Vector2f position(0.0f, 270.0f);
    float v0 = (2.0f);
    float vFinal = (20.0f);
    float deltaTime = (2.0f/60.0f);

    while (App.isOpen()) {
        while (App.pollEvent(evt)) {
            if (evt.type == Event::Closed)
                App.close();
        }
        position.x += v0 * deltaTime;
        if (position.x > 830.0f) {
            position.x = -30.0f;
            if (v0 <  vFinal) {
                v0 += 2.0f;
            }
        }
        App.clear();
        circle.setPosition(position);
        App.draw(circle);
        App.display();
    }
    return 0;
}