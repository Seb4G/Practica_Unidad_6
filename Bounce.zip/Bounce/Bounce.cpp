#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
using namespace sf;

int main() {
    RenderWindow App(VideoMode(800, 600), "Bounce");
    Event evt;
    CircleShape ball(30);
    ball.setFillColor(Color::Green);
    Vector2f position (370.0f, 0.0f);
    Vector2f velocity (30.0f, 0.0f);
    float acceleration(60.0f);
    float deltaTime = (0.1f/60.0f);
    float gravedad = (0.9f);

    while (App.isOpen()) {
        while (App.pollEvent(evt)) {
            App.clear();
            if (evt.type == Event::Closed)
                App.close();
        }
        position.y += velocity.y * deltaTime;
        velocity.y += acceleration * deltaTime;
        if (position.y > 540.0f) {
            position.y = 540.0f;
            velocity.y = -velocity.y * gravedad;
        }
        App.clear();
        ball.setPosition(position);
        App.draw(ball);
        App.display();
    }
    return 0;
}
