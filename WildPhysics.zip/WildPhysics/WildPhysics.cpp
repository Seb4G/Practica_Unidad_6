#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
using namespace sf;
using namespace std;

class Texto {
public:
    Texto();
    void actTexto(int puntaje);
    void drawTexto(RenderWindow& App);
private:
    Font font;
    Text text;
};
Texto::Texto() {
    if (!font.loadFromFile("fuente.TTF")) {}
    text.setFont(font);
    text.setCharacterSize(43);
    text.setFillColor(Color::White);
    text.setPosition(690, 750);
}
void Texto::actTexto(int puntaje) {
    text.setString("Puntaje: " + to_string(puntaje));
}
void Texto::drawTexto(RenderWindow& App) {
    App.draw(text);
}

class Diana {
public:
    Diana();
    void posDiana();
    void posDiana2();
    void drawDiana(RenderWindow& App);
    bool click(int mouseX, int mouseY);

private:
    Texture texturaDiana;
    Sprite spriteDiana;
    Vector2f position;
    Vector2f velocity;
    Vector2f position2;
    Vector2f velocity2;
    float acceleration;
    float acceleration2;
    float deltaTime;
};
Diana::Diana() : acceleration(30.0f), acceleration2(0.1f), deltaTime(0.1f / 60.0f){
    position = Vector2f(100.0f, 0.0f);
    velocity = Vector2f(50.0f, 50.0f);
    position2 = Vector2f(-50.0f, 250.0f);
    velocity2 = Vector2f(400.0f, 00.0f);
    if (!texturaDiana.loadFromFile("diana.png")) {}
    spriteDiana.setTexture(texturaDiana);
    spriteDiana.setScale(0.2f, 0.2f);
}
void Diana::posDiana() {
    velocity.y += acceleration * deltaTime;
    position.y += velocity.y * deltaTime;
    if (position.y > 640.0f) {
        position.y = 640.0f;
        velocity.y = -velocity.y;
    }
    spriteDiana.setPosition(position);
}
void Diana::posDiana2() {
    velocity2.x += acceleration2 * deltaTime;
    position2 += velocity2 * deltaTime;
    if (position2.x > 1350.0f) {
        position2.x = -500.0f;
    }
    spriteDiana.setPosition(position2);
}
void Diana::drawDiana(RenderWindow& App) {
    App.draw(spriteDiana);
}
bool Diana::click(int mouseX, int mouseY) {
    return spriteDiana.getGlobalBounds().contains((mouseX), (mouseY));
}

int main() {
    RenderWindow App(VideoMode(1000, 800), "Wild Physics");
    Event evt;
    Diana diana1;
    Diana diana2;
    Texto texto;
    int puntaje = 0;
    texto.actTexto(puntaje);

    while (App.isOpen()) {
        while (App.pollEvent(evt)) {
            if (evt.type == Event::Closed) {
                App.close();
            }
            if (evt.type == Event::MouseButtonPressed && evt.mouseButton.button == Mouse::Left) {
                int mouseX = evt.mouseButton.x;
                int mouseY = evt.mouseButton.y;
                if (diana1.click(mouseX, mouseY)) {
                    puntaje++;
                }
                if (diana2.click(mouseX, mouseY)) {
                    puntaje++;
                }
                texto.actTexto(puntaje);
            }
        }
        App.clear();
        texto.drawTexto(App);
        diana1.posDiana();
        diana2.posDiana2();
        diana1.drawDiana(App);
        diana2.drawDiana(App);
        App.display();
    }
    return 0;
}